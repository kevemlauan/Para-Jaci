function showSurprise() {
  document.getElementById("surprise").classList.remove("hidden");
}
